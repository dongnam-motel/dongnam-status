import { Card, CardContent } from "@/components/ui/card";
import { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";
import { Button } from "@/components/ui/button";

// Supabase 연결 정보
const supabaseUrl = "https://vgskyyihyqkpxjhsngzb.supabase.co";
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...";
const supabase = createClient(supabaseUrl, supabaseKey);

// 현황판 컴포넌트
export default function RoomStatusBoard() {
  return <div>동남모텔 현황판입니다.</div>;
}
